print("Hello World From Python!\n\n")

print("I will show you some data!!!")

myname = "John Jacob Gingleheimershmitt"

age = 18

eyes = "hazel"

print(f"hello, {myname}. You are {age} years old. You have real nice {eyes} eyes.")